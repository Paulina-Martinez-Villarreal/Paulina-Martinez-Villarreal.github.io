<link rel="stylesheet" href="style.css">
<?php
	echo "<h1>Codigo de producto: " .$_GET['id']."</h1>";
	echo "<br>";
	echo "<h1>Producto: " .$_GET['nombre']."</h1>";
?>