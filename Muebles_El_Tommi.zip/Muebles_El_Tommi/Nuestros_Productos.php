<html>
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
 <link rel="stylesheet" type="text/css" href="estilos/Con-Margen.css">
<script src='https://code.jquery.com/jquery-3.2.1.min.js'></script>
<link rel="stylesheet" href="estilos/Estilos_De_Formulario_De_Compras.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">

  <title>Nuestros productos</title>
 </head>
<body id='body'>


<center>
  <table>
</center>

<tr>
<th><b CLASS="texto"></b></th>
<th><b CLASS="texto"></b></th>
<th><b CLASS="texto"></b></th>
</tr>


<tr>
<td><a title="HOME" href="index.php"><img src="imagenes/casa4.jpg" height="50" alt="HOME" onmouseover="imagen1();" onmouseout="imagen2();" id="i"/></a><br><p><pre>                             </pre></p></td>



<td><center>
<button id='tema'>CAMBIAR TEMA</button>
<p id="result">TEMA </p>
</center><p><pre>                                                                                                                  </pre></p></td>


<td><a title="Siguiente" href="Ofertas.html" target="_blank"><img src="imagenes/Flecha-Roja.jpg" height="50" alt="Siguiente" onmouseover="imagen3();" onmouseout="imagen4();" id="o"/></a></td>
</tr>
</table>



<div class="titulo">Catalogo de productos</div>
<div class="container">
	<div class="caja caja1"><img src="imagenes/p1.png"><p>Sala esquinera Prisca - Gris claro</p>
	<p>Precio: $6,299.00</p></div>
	
	<div class="caja caja1"><img src="imagenes/p2.png"><p>Mesa de comedor Xoco 120cm - Nogal</p>
	<p>Precio: $7,499.00</p></div>

	<div class="caja caja1"><img src="imagenes/p3.webp"><p>Loveseat Dovve Contemporáneo</p>
	<p>Precio: $4,299</p></div>
	
	<div class="caja caja1"><img src="imagenes/p4.png"><p>Mesa de comedor Evo 200cm - Encino</p>
	<p>Precio: $8,799.00</p></div>

	<div class="caja caja1"><img src="imagenes/p5.png"><p>Sala Esquinera en U Corbel </p>
	<p>Precio: $12,499.00</p></div>
	
	<div class="caja caja1"><img src="imagenes/p6.png"><p>Librero Blancx B</p>
	<p>Precio: $1,599.00</p></div>
	
	<div class="caja caja1"><img src="imagenes/p7.png"><p>Vitrina Meztli B -Nogal</p>
	<p>Precio: $4,999.00</p></div>
	
	<div class="caja caja1"><img src="imagenes/p8.jpeg"><p> Mueble de TV Mesa y Marco</p>
	<p>Precio: $1,699.00</p></div>
	
	<div class="caja caja1"><img src="imagenes/p9.jpeg"><p>Mueble Multiusos para Cocina </p>
	<p>Precio: $2,999.00</p></div>


</div><br><br><br><br><br>


 
<form method="post" action="contact.php">
 
<p>
 
<label for="NameUsuario">Nombre</label>
 
<input type="text" name="txtNameUsuario" id="txtNameUsuario" required>
 
</p>
 
<p>
 
<label for="Correo">Correo</label>
 
<input type="email" name="txtCorreo" id="txtCorreo" required>
 
</p>
 
<p>
 
<label for="Tarjeta de credito">Tarjeta de credito</label>
 
<input type="password" name="txtTarjetaCredito" id="txtTarjetaCredito" required >
 
</p>
 

<p>
 
<label for="NombreProducto">Nombre del producto</label>
 
<textarea name="txtNombreProducto" id="txtNombreProducto" required ></textarea>
 
</p>
 

<p>
 
<label for="Cantidad">Cantidad</label>
 
<textarea name="txtCantidad" id="txtCantidad" required ></textarea>
 
</p>
 
 
 
<p>&nbsp;</p>
 
<p>
 
<input type="submit" name="submit" id="submit" value="submit">
 
</p>
 
</form>



 </body>
 
 <script src="JavaScript/Java.js" type="text/javascript" charset="utf-8"></script>
 

</html>